# Binance Bot Fullstack
This repo contains a FastAPI backend and React frontend to place orders on Binance Futures Testnet.
## Quick start
1. Copy backend/.env.example -> backend/.env and fill your TESTNET keys.
2. docker-compose up --build
3. Open http://localhost:3000 for frontend
