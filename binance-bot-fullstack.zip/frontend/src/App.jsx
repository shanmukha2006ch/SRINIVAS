        import React, { useState } from 'react'
export default function App(){
  const [symbol, setSymbol] = useState('BTCUSDT')
  const [side, setSide] = useState('BUY')
  const [type, setType] = useState('MARKET')
  const [quantity, setQuantity] = useState('0.001')
  const [price, setPrice] = useState('')
  const [stopPrice, setStopPrice] = useState('')
  const [twapSlices, setTwapSlices] = useState('3')
  const [twapInterval, setTwapInterval] = useState('60')
  const [result, setResult] = useState(null)
  const [loading, setLoading] = useState(false)
  async function submit(e){
    e.preventDefault()
    if(type === 'LIMIT' && !price){ alert('Price required for LIMIT') ; return }
    if(type === 'OCO' && (!price || !stopPrice)){ alert('OCO requires price and stop price'); return }
    setLoading(true); setResult(null)
    const payload = { symbol, side, type, quantity, price: price||undefined, stop_price: stopPrice||undefined, twap_slices: parseInt(twapSlices||'3'), twap_interval_seconds: parseInt(twapInterval||'60') }
    try{
      const resp = await fetch('http://localhost:8000/api/order', { method: 'POST', headers: {'Content-Type':'application/json'}, body: JSON.stringify(payload) })
      const data = await resp.json()
      setResult(data)
    }catch(err){ setResult({error:true, message: err.message}) }
    setLoading(false)
  }
  return (
    <div style={{maxWidth:800, margin:'2rem auto', fontFamily:'Arial'}}>
      <h2>Binance Testnet — Place Order</h2>
      <form onSubmit={submit}>
        <label>Symbol<br/><input value={symbol} onChange={e=>setSymbol(e.target.value)} /></label>
        <label>Side<br/><select value={side} onChange={e=>setSide(e.target.value)}><option>BUY</option><option>SELL</option></select></label>
        <label>Type<br/><select value={type} onChange={e=>setType(e.target.value)}><option>MARKET</option><option>LIMIT</option><option>OCO</option><option>TWAP</option></select></label>
        <label>Quantity<br/><input value={quantity} onChange={e=>setQuantity(e.target.value)} /></label>
        <label>Price (for LIMIT / OCO)<br/><input value={price} onChange={e=>setPrice(e.target.value)} /></label>
        <label>Stop Price (for OCO / STOP_LIMIT)<br/><input value={stopPrice} onChange={e=>setStopPrice(e.target.value)} /></label>
        <label>TWAP slices<br/><input value={twapSlices} onChange={e=>setTwapSlices(e.target.value)} /></label>
        <label>TWAP interval (s)<br/><input value={twapInterval} onChange={e=>setTwapInterval(e.target.value)} /></label>
        <div style={{marginTop:10}}><button type="submit" disabled={loading}>{loading? 'Placing...':'Place Order'}</button></div>
      </form>
      <h3>Result</h3>
      <pre style={{background:'#f4f4f4', padding:10}}>{result? JSON.stringify(result, null, 2) : 'No orders yet.'}</pre>
    </div>
  )
}
