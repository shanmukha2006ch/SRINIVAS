import time, hmac, hashlib
from urllib.parse import urlencode
import httpx
from typing import Dict, Any
from .logger import get_logger
from .settings import settings
logger = get_logger('binance_client')
class BinanceClient:
    def __init__(self, api_key: str, api_secret: str, base_url: str):
        self.api_key = api_key
        self.api_secret = api_secret.encode('utf-8')
        self.base_url = base_url.rstrip('/')
        self.timeout = 10
    def _sign(self, payload: Dict[str, Any]) -> str:
        query = urlencode(payload)
        signature = hmac.new(self.api_secret, query.encode('utf-8'), hashlib.sha256).hexdigest()
        return f"{query}&signature={signature}"
    async def post_order(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        path = '/fapi/v1/order'
        url = f"{self.base_url}{path}"
        headers = {'X-MBX-APIKEY': self.api_key, 'Content-Type': 'application/x-www-form-urlencoded'}
        signed = self._sign(payload)
        async with httpx.AsyncClient(timeout=self.timeout) as client:
            try:
                resp = await client.post(url, content=signed, headers=headers)
                resp.raise_for_status()
                return resp.json()
            except httpx.HTTPStatusError as exc:
                logger.exception('Binance API returned error')
                return {'error': True, 'message': str(exc), 'status_code': exc.response.status_code, 'body': exc.response.text}
            except Exception as exc:
                logger.exception('Network or other error')
                return {'error': True, 'message': str(exc)}
    async def place_order(self, symbol: str, side: str, order_type: str, quantity: float, price: float = None, stop_price: float = None):
        timestamp = int(time.time() * 1000)
        payload = {
            'symbol': symbol.upper(),
            'side': side.upper(),
            'type': order_type.upper(),
            'quantity': str(quantity),
            'timestamp': timestamp,
            'recvWindow': 5000,
        }
        if order_type.upper() == 'LIMIT':
            if price is None:
                raise ValueError('Price is required for LIMIT orders')
            payload['price'] = str(price)
            payload['timeInForce'] = 'GTC'
        if order_type.upper() == 'STOP_LIMIT':
            if price is None or stop_price is None:
                raise ValueError('STOP_LIMIT requires price and stop_price')
            payload['price'] = str(price)
            payload['stopPrice'] = str(stop_price)
            payload['timeInForce'] = 'GTC'
        # For OCO and TWAP we implement higher-level logic in the backend; OCO maps to two orders where supported
        logger.info('Sending order payload to Binance: %s', payload)
        return await self.post_order(payload)
client = BinanceClient(settings.binance_api_key, settings.binance_api_secret, settings.testnet_base_url)
