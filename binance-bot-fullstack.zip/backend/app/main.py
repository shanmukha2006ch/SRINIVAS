from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from .schemas import OrderRequest, OrderResponse = None, ErrorResponse = None
# NOTE: Response models are imported below to avoid circular typing in this minimal file
from .client import client
from .logger import get_logger
logger = get_logger('backend')
app = FastAPI(title='Binance Testnet Simplified Trading Bot', version='1.1')
app.add_middleware(CORSMiddleware, allow_origins=['*'], allow_credentials=True, allow_methods=['*'], allow_headers=['*'])
# Simple runtime definitions for response mapping
@app.post('/api/order')
async def place_order(req: OrderRequest):
    try:
        logger.info('Received order: %s %s %s', req.symbol, req.side, req.type)
        # Handle TWAP: slice into N smaller MARKET orders
        if req.type.upper() == 'TWAP':
            slices = req.twap_slices or 3
            interval = req.twap_interval_seconds or 60
            qty_per = float(req.quantity) / slices
            results = []
            for i in range(slices):
                logger.info('TWAP slice %d/%d placing MARKET qty %s', i+1, slices, qty_per)
                r = await client.place_order(req.symbol, req.side, 'MARKET', qty_per)
                results.append(r)
            return {'error': False, 'order': {'twap_results': results, 'slices': slices}}
        # Handle OCO naive emulation: place primary LIMIT and a STOP_LIMIT opposite or vice versa
        if req.type.upper() == 'OCO':
            # This is a simplified emulation: create two orders (LIMIT and STOP_LIMIT)
            if req.price is None or req.stop_price is None:
                raise ValueError('OCO requires price and stop_price')
            primary = await client.place_order(req.symbol, req.side, 'LIMIT', req.quantity, price=float(req.price))
            stop = await client.place_order(req.symbol, req.side, 'STOP_LIMIT', req.quantity, price=float(req.price), stop_price=float(req.stop_price))
            return {'error': False, 'order': {'primary': primary, 'stop': stop}}
        # Regular orders
        result = await client.place_order(req.symbol, req.side, req.type, float(req.quantity), price=(float(req.price) if req.price else None), stop_price=(float(req.stop_price) if req.stop_price else None))
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        logger.exception('Unexpected error')
        raise HTTPException(status_code=500, detail='internal error')
    if isinstance(result, dict) and result.get('error'):
        return {'error': True, 'message': result.get('message')}
    return {'error': False, 'order': result}
@app.get('/health')
async def health():
    return {'status': 'ok'}
