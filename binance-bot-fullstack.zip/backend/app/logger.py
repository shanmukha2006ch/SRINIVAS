import logging, sys
def get_logger(name=__name__):
    logger = logging.getLogger(name)
    if not logger.handlers:
        handler = logging.StreamHandler(sys.stdout)
        fmt = ('%(asctime)s | %(levelname)-7s | %(name)s | %(message)s')
        handler.setFormatter(logging.Formatter(fmt))
        logger.setLevel(logging.INFO)
        logger.addHandler(handler)
    return logger
