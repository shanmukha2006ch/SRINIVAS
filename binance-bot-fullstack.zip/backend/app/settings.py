from pydantic import BaseSettings, AnyHttpUrl
class Settings(BaseSettings):
    binance_api_key: str
    binance_api_secret: str
    testnet_base_url: AnyHttpUrl = 'https://testnet.binancefuture.com'
    host: str = '0.0.0.0'
    port: int = 8000
    class Config:
        env_file = '.env'
        env_file_encoding = 'utf-8'
settings = Settings()
