from pydantic import BaseModel, Field, constr, condecimal
from typing import Optional
class OrderRequest(BaseModel):
    symbol: constr(strip_whitespace=True, min_length=3)
    side: constr(to_upper=True) = Field(..., regex='^(BUY|SELL)$')
    type: constr(to_upper=True) = Field(..., regex='^(MARKET|LIMIT|STOP_LIMIT|OCO|TWAP)$')
    quantity: condecimal(gt=0)
    price: Optional[condecimal(gt=0)] = None
    stop_price: Optional[condecimal(gt=0)] = None
    # TWAP params
    twap_slices: Optional[int] = None
    twap_interval_seconds: Optional[int] = None
